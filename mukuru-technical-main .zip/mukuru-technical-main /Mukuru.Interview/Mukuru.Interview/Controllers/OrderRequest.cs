﻿namespace Mukuru.Interview.Controllers
{
    public class OrderRequest
    {
        public int OrderId { get; set; }
        public List<int> ItemPrices { get; set; }
        public bool HasDiscount { get; set; }
    }
}
