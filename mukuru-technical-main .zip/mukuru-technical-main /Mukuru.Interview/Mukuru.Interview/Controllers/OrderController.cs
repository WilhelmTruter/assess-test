using Microsoft.AspNetCore.Mvc;

namespace Mukuru.Interview.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly ILogger<OrderController> _logger;

        public OrderController(ILogger<OrderController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetOrders")]
        public IEnumerable<object> Get()
        {
            List<OrderRequest> orders = null;
            ProductOrderingService orderingService = new ProductOrderingService();
            orders = orderingService.ReturnOrders();
            return orders;
        }

        [HttpGet(Name = "PlaceOrder")]
        public ActionResult PlaceOrder([FromBody] OrderRequest request)
        {
            object result;

            ProductOrderingService orderingService = new ProductOrderingService();
            result = orderingService.ProcessOrder(request.OrderId, request.ItemPrices, request.HasDiscount);

            return Ok(result);
        }
    }
}
