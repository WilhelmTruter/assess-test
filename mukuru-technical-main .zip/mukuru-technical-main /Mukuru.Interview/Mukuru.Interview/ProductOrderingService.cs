﻿using Microsoft.Data.Sqlite;
using Mukuru.Interview.Controllers;

namespace Mukuru.Interview
{
    public class ProductOrderingService
    {
        public ProductOrderingService()
        {
            using (var connection = new SqliteConnection("Data Source=source.db"))
            {
                connection.Open();

                using (var command = new SqliteCommand(@"
                CREATE TABLE IF NOT EXISTS OrderRequest (
                    OrderId INTEGER PRIMARY KEY,
                    ItemPrices TEXT,
                    TotalPrice INTEGER,
                    HasDiscount INTEGER
                );", connection))
                {
                    command.ExecuteNonQuery();
                }

            }
        }
        public object ProcessOrder(int orderId, List<int> itemPrices, bool hasDiscount)
        {
            // Calculate total price
            double totalPrice = 0;
            foreach (var price in itemPrices)
            {
                totalPrice += price;
            }

            if (hasDiscount)
            {
                totalPrice = totalPrice * 0.9; // Apply discount
            }

            string prices = string.Join(",", itemPrices);

            using (var connection = new SqliteConnection("Data Source=source.db"))
            {
                connection.Open();

                using (var command = new SqliteCommand(@"
            INSERT INTO OrderRequest (OrderId, ItemPrices, HasDiscount) 
            VALUES (@OrderId, @ItemPrices, @HasDiscount);", connection))
                {
                    command.Parameters.AddWithValue("@OrderId", orderId);
                    command.Parameters.AddWithValue("@ItemPrices", prices);
                    command.Parameters.AddWithValue("@HasDiscount", hasDiscount ? 1 : 0);
                    command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                    command.ExecuteNonQuery();
                }
            }

            // Check user and payment statuses
            bool userstatus = GetUserStatus();
            bool paymentstatus = GetPaymentStatus();

            if (userstatus && paymentstatus)
            {
                return "User is active and payment is complete.";
            }
            else
            {
                return "Either user is not active or payment is not complete.";
            }
        }

        public List<OrderRequest> ReturnOrders()
        {

            List<OrderRequest> orderRequests = new List<OrderRequest>();

            using (var connection = new SqliteConnection("Data Source=source.db"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT OrderId, ItemPrices, HasDiscount FROM OrderRequest;";

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var orderRequest = new OrderRequest
                        {
                            OrderId = Convert.ToInt32(reader["OrderId"]),
                            ItemPrices = new List<int>(Array.ConvertAll(reader["ItemPrices"].ToString().Split(','), int.Parse)),
                            HasDiscount = Convert.ToBoolean(reader["HasDiscount"])
                        };

                        orderRequests.Add(orderRequest);
                    }
                }
            }

            return orderRequests;
        }

        private bool GetUserStatus()
        {
            // Simulate checking user status
            return true;
        }

        private bool GetPaymentStatus()
        {
            // Simulate checking payment status
            return true;
        }
    }
}
